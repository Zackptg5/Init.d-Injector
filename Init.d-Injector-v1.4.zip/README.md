# Init.d-Injector
Injects init.d support into the kernel
Build with AnyKernel2 by Osm0sis (https://github.com/osm0sis/AnyKernel2/)
Uses setools by Xmikos (https://github.com/xmikos/setools-android)
Based off of init.d injection by CosmicDan @xda-developers
Support Thread: https://forum.xda-developers.com/android/software-hacking/mod-universal-init-d-injector-wip-t3692105